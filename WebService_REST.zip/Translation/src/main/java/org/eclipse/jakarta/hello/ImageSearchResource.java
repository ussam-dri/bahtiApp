package org.eclipse.jakarta.hello;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.json.JSONObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Path("image")
public class ImageSearchResource {
    private static final String API_KEY = "AIzaSyCcWWbB0FzPrZqeehhZPfzITbBLWYXcycY";
    private static final String SEARCH_ENGINE_ID = "5111c3d7822a44be4";
    private static final String API_URL = "https://www.googleapis.com/customsearch/v1";

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getImage(@QueryParam("query") String query) {
        if (query == null || query.isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"error\": \"Query parameter is required\"}")
                    .build();
        }

        try {
            HttpClient client = HttpClient.newHttpClient();
            String searchUrl = String.format("%s?key=%s&cx=%s&q=%s&searchType=image&num=1",
                    API_URL, API_KEY, SEARCH_ENGINE_ID, query);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(searchUrl))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request,
                    HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity("{\"error\": \"API request failed\"}")
                        .build();
            }

            // Parse the response and extract the first image URL
            JSONObject jsonResponse = new JSONObject(response.body());
            if (!jsonResponse.has("items") || jsonResponse.getJSONArray("items").length() == 0) {
                return Response.status(Response.Status.NOT_FOUND)
                        .entity("{\"error\": \"No images found for the query\"}")
                        .build();
            }

            String imageUrl = jsonResponse.getJSONArray("items")
                    .getJSONObject(0)
                    .getString("link");

            JSONObject result = new JSONObject();
            result.put("query", query);
            result.put("imageUrl", imageUrl);

            return Response.ok(result.toString(), MediaType.APPLICATION_JSON).build();

        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("{\"error\": \"Failed to fetch image: " + e.getMessage() + "\"}")
                    .build();
        }
    }
}