package org.eclipse.jakarta.hello;

import io.github.cdimascio.dotenv.Dotenv;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Arrays;
import java.util.List;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

@Path("generate")
@Produces(MediaType.APPLICATION_JSON)
public class GenerateResource {
    //private static final Dotenv dotenv = Dotenv.load();

    //String GEMINI_API_KEY = dotenv.get("GEMINI_API_KEY");
    //String IMAGE_API_KEY = dotenv.get("IMAGE_API_KEY");
    //String SEARCH_ENGINE_ID = dotenv.get("SEARCH_ENGINE_ID");

    String GEMINI_API_KEY = "AIzaSyCcWWbB0FzPrZqeehhZPfzITbBLWYXcycY";
    String  IMAGE_API_KEY = "AIzaSyCcWWbB0FzPrZqeehhZPfzITbBLWYXcycY";
    String SEARCH_ENGINE_ID = "5111c3d7822a44be4";

    private static final String GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent";
    private static final String IMAGE_API_URL = "https://www.googleapis.com/customsearch/v1";
    //  CORS filter configuration due to some errors
    List<String> allowedOrigins = Arrays.asList("*", "192.168.0.107");
    @OPTIONS
    public Response corsPreflightResponse() {
        return Response.ok()
                .header("Access-Control-Allow-Origin", allowedOrigins)  // Use * for all origins or set your specific origin
                .header("Access-Control-Allow-Methods", "POST, OPTIONS")
                .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                .header("Access-Control-Max-Age", "86400") // Cache preflight for 24 hours
                .build();
    }
        //generate  content based on the specified topic, language, and numLines
    private String generateText(String topic, String language, int numLines) throws ApiException {
        try {
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .build();

            String prompt = switch (language.toLowerCase()) {
                case "arabic" -> String.format("Write %d lines in Arabic about '%s'. Make it educational and interesting.", numLines, topic);
                case "french" -> String.format("Écrivez %d lignes en français sur '%s'. Rendez-le éducatif et intéressant.", numLines, topic);
                case "english" -> String.format("Write %d lines in English about '%s'. Make it educational and interesting.", numLines, topic);
                default -> throw new ApiException("Unsupported language: " + language);
            };
            //build the json POST request body
            JSONObject requestBody = new JSONObject()
                    .put("contents", new JSONArray()
                            .put(new JSONObject()
                                    .put("parts", new JSONArray()
                                            .put(new JSONObject()
                                                    .put("text", prompt)))));
            // build the POST REQUEST
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(GEMINI_API_URL + "?key=" + GEMINI_API_KEY))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody.toString()))
                    .timeout(Duration.ofSeconds(30))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException("Gemini API failed with status code: " + response.statusCode() +
                        ", Response: " + response.body());
            }

            JSONObject responseJson = new JSONObject(response.body());
            if (!responseJson.has("candidates") || responseJson.getJSONArray("candidates").isEmpty()) {
                throw new ApiException("No content generated from Gemini API");
            }
            //parse JSON RESPONSE to return text
            return responseJson.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim();

        } catch (Exception e) {
            throw new ApiException("Text generation failed: " + e.getMessage());
        }
    }
                // function to fetch images based on topic and number of images
    private JSONArray fetchImages(String topic, int numImages) throws ApiException {
        try {
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .build();

            String encodedTopic = URLEncoder.encode(topic, StandardCharsets.UTF_8);
            //making search URL to the custom google engine
            String searchUrl = String.format("%s?key=%s&cx=%s&q=%s&searchType=image&num=%d&safe=active",
                    IMAGE_API_URL,
                    IMAGE_API_KEY,
                    SEARCH_ENGINE_ID,
                    encodedTopic,
                    Math.min(numImages, 10));
            //sending the GET REQUEST to get the images
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(searchUrl))
                    .GET()
                    .timeout(Duration.ofSeconds(30))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException("Image search failed. Status: " + response.statusCode());
            }
                /// making a JSON ARRAY "imageUrls" that contains image URLS
            JSONObject searchResponse = new JSONObject(response.body());
            JSONArray imageUrls = new JSONArray();

            if (searchResponse.has("items")) {
                JSONArray items = searchResponse.getJSONArray("items");
                for (int i = 0; i < Math.min(items.length(), numImages); i++) {
                    JSONObject item = items.getJSONObject(i);
                    if (item.has("link")) {
                        imageUrls.put(item.getString("link"));
                    }
                }
            }

            return imageUrls;

        } catch (Exception e) {
            throw new ApiException("Image fetching failed: " + e.getMessage());
        }
    }
            // the main function to generate content === the webserivce method
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response generateContent(String requestBody) {
        try {
            if (requestBody == null || requestBody.isEmpty()) {
                return createErrorResponse(Response.Status.BAD_REQUEST, "Request body cannot be empty");
            }

            JSONObject request = new JSONObject(requestBody);
            ValidationResult validation = validateRequest(request);
            if (!validation.isValid()) {
                return createErrorResponse(Response.Status.BAD_REQUEST, validation.getMessage());
            }
        /// retrives fields from the post request
            String topic = request.getString("topic");
            String language = request.getString("language");
            int numLines = request.getInt("numLines");
            int numImages = request.getInt("numImages");
                // calls the generate text function
            String translatedText = generateText(topic, language, numLines);
            // calls generate Images function
            JSONArray images = fetchImages(topic, numImages);

            JSONObject response = new JSONObject()
                    .put("text", translatedText)
                    .put("images", images);
            // sends the response to the Front End
            return Response.ok(response.toString())
                    .header("Access-Control-Allow-Origin", "*")  // Use * for all origins or set your specific origin
                    .header("Access-Control-Allow-Methods", "POST, OPTIONS")
                    .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                    .build();

        } catch (JSONException e) {
            return createErrorResponse(Response.Status.BAD_REQUEST, "Invalid JSON format: " + e.getMessage());
        } catch (ApiException e) {
            return createErrorResponse(Response.Status.SERVICE_UNAVAILABLE, "API error: " + e.getMessage());
        } catch (Exception e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Internal server error: " + e.getMessage());
        }
    }

    private Response createErrorResponse(Response.Status status, String message) {
        JSONObject error = new JSONObject().put("error", message);
        return Response.status(status)
                .entity(error.toString())
                .header("Access-Control-Allow-Origin", "*")  // Use * for all origins or set your specific origin
                .header("Access-Control-Allow-Methods", "POST, OPTIONS")
                .header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                .build();
    }

    private ValidationResult validateRequest(JSONObject request) {
        try {
            if (!request.has("topic") || request.getString("topic").trim().isEmpty()) {
                return new ValidationResult(false, "Topic is required");
            }
            if (!request.has("language") || request.getString("language").trim().isEmpty()) {
                return new ValidationResult(false, "Language is required");
            }
            if (!request.has("numLines") || request.getInt("numLines") <= 0) {
                return new ValidationResult(false, "Number of lines must be positive");
            }
            if (!request.has("numImages") || request.getInt("numImages") <= 0) {
                return new ValidationResult(false, "Number of images must be positive");
            }

            String language = request.getString("language").toLowerCase();
            if (!language.equals("arabic") && !language.equals("french") && !language.equals("english")) {
                return new ValidationResult(false, "Unsupported language. Supported languages are: Arabic, French, English");
            }

            return new ValidationResult(true, "");
        } catch (JSONException e) {
            return new ValidationResult(false, "Invalid request format: " + e.getMessage());
        }
    }

    // ValidationResult class
    public static class ValidationResult {
        private final boolean valid;
        private final String message;

        public ValidationResult(boolean valid, String message) {
            this.valid = valid;
            this.message = message;
        }

        public boolean isValid() {
            return valid;
        }

        public String getMessage() {
            return message;
        }
    }

    class ApiException extends Exception {
        public ApiException(String message) {
            super(message);
        }
    }
}
